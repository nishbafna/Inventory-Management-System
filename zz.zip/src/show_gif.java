/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Naman Doshi
 */
import java.io.*;
import javax.swing.*;
public class show_gif extends javax.swing.JFrame {

  public static void main(String args[])
  {System.out.println("fuck off"); 
}
}